<?php
declare(strict_types=1);

/**
 * POST /api/contact.php — receives the website contact form.
 *
 * Request  (JSON): { name, email, company, phone, service, message, website, sourcePage }
 * Responses (JSON):
 *   200 { ok: true, id, emailSent }        enquiry stored and/or emailed
 *   422 { ok: false, errors: {field: msg} } validation failed
 *   429 { ok: false, message }             too many submissions
 *   503 { ok: false, message }             backend not configured yet (no DB, no email)
 *   500/502 { ok: false, message }         server / email error
 */

use Silgrid\ContactRepository;
use Silgrid\ContactValidator;
use Silgrid\Database;
use Silgrid\Http;
use Silgrid\Logger;
use Silgrid\Mailer;
use Silgrid\RateLimiter;

$config = require (require __DIR__ . '/app-path.php') . '/bootstrap.php';

Http::applyCors();

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST, OPTIONS');
    Http::json(405, ['ok' => false, 'message' => 'Method not allowed.']);
}

$input = Http::readJsonBody();
if ($input === null) {
    Http::json(400, ['ok' => false, 'message' => 'Invalid request.']);
}

// Honeypot: real visitors never see or fill the "website" field.
// Bots get a normal-looking reply and nothing is stored or sent.
if (trim((string) ($input['website'] ?? '')) !== '') {
    Http::json(200, ['ok' => true, 'emailSent' => true]);
}

[$data, $errors] = ContactValidator::validate($input, $config['allowed_services']);
if ($errors) {
    Http::json(422, ['ok' => false, 'message' => 'Please check the highlighted fields.', 'errors' => $errors]);
}

$dbEnabled = Database::isEnabled();
$mailEnabled = Mailer::isEnabled();
if (!$dbEnabled && !$mailEnabled) {
    Logger::error('Contact form used but neither DB_ENABLED nor MAIL_ENABLED is true in .env');
    Http::json(503, ['ok' => false, 'message' => 'Our contact form is being set up and cannot accept messages yet.']);
}

$ipHash = hash('sha256', Http::clientIp() . '|' . __DIR__);
if (RateLimiter::tooManyAttempts($ipHash)) {
    Http::json(429, ['ok' => false, 'message' => 'You have sent several messages recently. Please try again later.']);
}

// 1) Store in MySQL
$id = null;
if ($dbEnabled) {
    try {
        $id = ContactRepository::insert($data, $ipHash, (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
    } catch (\Throwable $e) {
        Logger::error('Database insert failed', ['message' => $e->getMessage()]);
        if (!$mailEnabled) {
            Http::json(500, ['ok' => false, 'message' => 'We could not save your message. Please try again shortly.']);
        }
    }
}

// 2) Email the SILGRID team
$emailSent = false;
if ($mailEnabled) {
    try {
        Mailer::sendEnquiryNotification($data, $id);
        $emailSent = true;
        if ($id !== null) {
            ContactRepository::markEmailSent($id);
        }
    } catch (\Throwable $e) {
        Logger::error('Email sending failed', ['message' => $e->getMessage(), 'submission_id' => $id]);
    }
}

// Success only if the enquiry actually reached SILGRID (stored OR emailed)
if ($id === null && !$emailSent) {
    Http::json(502, ['ok' => false, 'message' => 'We could not deliver your message. Please try again shortly.']);
}

Http::json(200, ['ok' => true, 'id' => $id, 'emailSent' => $emailSent]);
