<?php
/**
 * ─── WHERE IS THE PRIVATE "app" FOLDER? ─────────────────────
 * Default: two folders up, then "app".
 *   • Local development:  backend/public/api/  →  backend/app/
 *   • GoDaddy (recommended layout):
 *       /home/USERNAME/public_html/api/   ← this file
 *       /home/USERNAME/app/               ← private app folder (+ .env)
 *     → works with NO changes.
 * If you put the app folder somewhere else, change the path below,
 * e.g. return '/home/USERNAME/silgrid-app';
 */
return getenv('SILGRID_APP_DIR') ?: dirname(__DIR__, 2) . '/app';
