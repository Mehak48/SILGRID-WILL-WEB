<?php
declare(strict_types=1);

/**
 * GET /api/health.php?token=YOUR_TOKEN
 * GET /api/health.php?token=YOUR_TOKEN&send_test_email=1
 *
 * Checks the database connection and email settings after deployment.
 * Disabled (404) unless HEALTH_CHECK_TOKEN is set in .env.
 */

use Silgrid\Database;
use Silgrid\Env;
use Silgrid\Http;
use Silgrid\Mailer;

require (require __DIR__ . '/app-path.php') . '/bootstrap.php';

$token = Env::get('HEALTH_CHECK_TOKEN');
if ($token === '' || !hash_equals($token, (string) ($_GET['token'] ?? ''))) {
    Http::json(404, ['ok' => false, 'message' => 'Not found.']);
}

$result = [
    'ok' => true,
    'php_version' => PHP_VERSION,
    'env_file_found' => is_file(APP_DIR . '/.env'),
    'storage_writable' => is_writable(APP_DIR . '/storage/logs') && is_writable(APP_DIR . '/storage/ratelimit'),
    'database' => ['enabled' => Database::isEnabled()],
    'email' => ['enabled' => Mailer::isEnabled()],
];

if (Database::isEnabled()) {
    try {
        $pdo = Database::connection();
        $result['database']['connected'] = true;
        $result['database']['table_exists'] = (bool) $pdo->query("SHOW TABLES LIKE 'contact_submissions'")->fetchColumn();
    } catch (\Throwable $e) {
        $result['ok'] = false;
        $result['database']['connected'] = false;
        $result['database']['error'] = $e->getMessage();
    }
}

if (Mailer::isEnabled() && isset($_GET['send_test_email'])) {
    try {
        Mailer::sendTest();
        $result['email']['test_email_sent'] = true;
    } catch (\Throwable $e) {
        $result['ok'] = false;
        $result['email']['test_email_sent'] = false;
        $result['email']['error'] = $e->getMessage();
    }
}

Http::json($result['ok'] ? 200 : 500, $result);
