-- ═════════════════════════════════════════════════════════════
--  SILGRID — database schema (MySQL 5.7+ / MariaDB 10.3+)
--  Run once in GoDaddy cPanel → phpMyAdmin → (select your DB) → SQL tab.
-- ═════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS contact_submissions (
  id           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  name         VARCHAR(100)  NOT NULL,
  email        VARCHAR(254)  NOT NULL,
  company      VARCHAR(150)  NULL,
  phone        VARCHAR(40)   NULL,
  service      VARCHAR(100)  NOT NULL,
  message      TEXT          NOT NULL,
  source_page  VARCHAR(50)   NULL COMMENT 'Page the form was sent from',
  ip_hash      CHAR(64)      NULL COMMENT 'SHA-256 of visitor IP (not the raw IP)',
  user_agent   VARCHAR(255)  NULL,
  email_sent   TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '1 = notification email delivered',
  status       ENUM('new','in_progress','closed') NOT NULL DEFAULT 'new',
  created_at   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_created_at (created_at),
  KEY idx_email (email),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
