<?php
declare(strict_types=1);

/**
 * Loads configuration and classes. Included by every file in public/api/.
 */
define('APP_DIR', __DIR__);

require APP_DIR . '/src/Env.php';
\Silgrid\Env::load(APP_DIR . '/.env');

// Never print PHP errors to visitors; they go to the log instead.
ini_set('display_errors', '0');
error_reporting(E_ALL);

require APP_DIR . '/src/Logger.php';
require APP_DIR . '/src/Http.php';
require APP_DIR . '/src/Database.php';
require APP_DIR . '/src/ContactValidator.php';
require APP_DIR . '/src/ContactRepository.php';
require APP_DIR . '/src/RateLimiter.php';
require APP_DIR . '/lib/PHPMailer/Exception.php';
require APP_DIR . '/lib/PHPMailer/PHPMailer.php';
require APP_DIR . '/lib/PHPMailer/SMTP.php';
require APP_DIR . '/src/Mailer.php';

set_exception_handler(static function (\Throwable $e): void {
    \Silgrid\Logger::error('Uncaught exception', ['type' => get_class($e), 'message' => $e->getMessage()]);
    \Silgrid\Http::json(500, ['ok' => false, 'message' => 'Something went wrong on our side. Please try again.']);
});

return require APP_DIR . '/config.php';
