<?php
declare(strict_types=1);

/**
 * Application settings that are NOT secret.
 * (Secrets such as passwords belong in .env, never here.)
 */
return [
    /**
     * Options accepted for "Service of interest".
     * ⚠ Must match `contactServiceOptions` in src/data/content.ts.
     */
    'allowed_services' => [
        'Industrial Materials & Technical Supplies',
        'IT Hardware & Technology Solutions',
        'Software & Licensing Services',
        'IT Support & Consultancy',
        'Procurement & Supply Chain',
        'Management & Facility Support',
        'General Enquiry',
    ],
];
