<?php
declare(strict_types=1);

namespace Silgrid;

/** Stores contact form submissions in the `contact_submissions` table. */
final class ContactRepository
{
    /** @param array<string,string> $data validated data */
    public static function insert(array $data, string $ipHash, string $userAgent): int
    {
        $sql = 'INSERT INTO contact_submissions
                  (name, email, company, phone, service, message, source_page, ip_hash, user_agent)
                VALUES
                  (:name, :email, :company, :phone, :service, :message, :source_page, :ip_hash, :user_agent)';
        $stmt = Database::connection()->prepare($sql);
        $stmt->execute([
            ':name' => $data['name'],
            ':email' => $data['email'],
            ':company' => $data['company'] !== '' ? $data['company'] : null,
            ':phone' => $data['phone'] !== '' ? $data['phone'] : null,
            ':service' => $data['service'],
            ':message' => $data['message'],
            ':source_page' => $data['sourcePage'] !== '' ? $data['sourcePage'] : null,
            ':ip_hash' => $ipHash,
            ':user_agent' => mb_substr($userAgent, 0, 255),
        ]);
        return (int) Database::connection()->lastInsertId();
    }

    public static function markEmailSent(int $id): void
    {
        $stmt = Database::connection()->prepare('UPDATE contact_submissions SET email_sent = 1 WHERE id = :id');
        $stmt->execute([':id' => $id]);
    }
}
