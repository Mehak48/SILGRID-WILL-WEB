<?php
declare(strict_types=1);

namespace Silgrid;

/**
 * Simple file-based rate limiter (works without the database).
 * Stores only a hash of the visitor's IP in app/storage/ratelimit/.
 */
final class RateLimiter
{
    public static function tooManyAttempts(string $ipHash): bool
    {
        $max = Env::int('RATE_LIMIT_MAX', 5);
        $window = Env::int('RATE_LIMIT_WINDOW_SECONDS', 3600);
        if ($max <= 0) {
            return false;
        }

        $dir = APP_DIR . '/storage/ratelimit';
        if (!is_dir($dir) || !is_writable($dir)) {
            Logger::error('Rate limit folder is not writable', ['dir' => $dir]);
            return false; // fail open: never block real customers because of a folder permission
        }

        $file = $dir . '/' . $ipHash . '.json';
        $now = time();
        $fp = fopen($file, 'c+');
        if ($fp === false) {
            return false;
        }
        flock($fp, LOCK_EX);
        $hits = json_decode(stream_get_contents($fp) ?: '[]', true);
        $hits = array_values(array_filter(is_array($hits) ? $hits : [], static fn ($t) => is_int($t) && $t > $now - $window));

        $blocked = count($hits) >= $max;
        if (!$blocked) {
            $hits[] = $now;
        }
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($hits));
        flock($fp, LOCK_UN);
        fclose($fp);

        // Occasionally clean up old files
        if (random_int(1, 50) === 1) {
            foreach (glob($dir . '/*.json') ?: [] as $f) {
                if (filemtime($f) < $now - $window) @unlink($f);
            }
        }
        return $blocked;
    }
}
