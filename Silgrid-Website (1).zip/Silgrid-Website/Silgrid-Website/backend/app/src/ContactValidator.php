<?php
declare(strict_types=1);

namespace Silgrid;

/**
 * Server-side validation. Mirrors src/lib/validation.ts in the frontend,
 * but is the one that actually counts — browsers can be bypassed.
 */
final class ContactValidator
{
    /**
     * @return array{0: array<string,string>, 1: array<string,string>} [cleanData, errors]
     */
    public static function validate(array $input, array $allowedServices): array
    {
        $str = static fn (string $k): string => is_string($input[$k] ?? null)
            ? trim(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $input[$k]) ?? '')
            : '';

        $d = [
            'name' => $str('name'),
            'email' => $str('email'),
            'company' => $str('company'),
            'phone' => $str('phone'),
            'service' => $str('service'),
            'message' => $str('message'),
            'sourcePage' => mb_substr($str('sourcePage'), 0, 50),
        ];
        $e = [];
        $len = static fn (string $s): int => mb_strlen($s);

        if ($d['name'] === '') $e['name'] = 'Please enter your name.';
        elseif ($len($d['name']) < 2) $e['name'] = 'Name is too short.';
        elseif ($len($d['name']) > 100) $e['name'] = 'Name must be under 100 characters.';

        if ($d['email'] === '') $e['email'] = 'Please enter your email address.';
        elseif ($len($d['email']) > 254 || filter_var($d['email'], FILTER_VALIDATE_EMAIL) === false) {
            $e['email'] = 'Please enter a valid email address.';
        }

        if ($len($d['company']) > 150) $e['company'] = 'Company must be under 150 characters.';

        if ($d['phone'] !== '' && !preg_match('/^[+()\-.\s0-9]{6,40}$/', $d['phone'])) {
            $e['phone'] = 'Please enter a valid phone number.';
        }

        if ($d['service'] === '') $e['service'] = 'Please choose a service.';
        elseif (!in_array($d['service'], $allowedServices, true)) $e['service'] = 'Please choose a service from the list.';

        if ($d['message'] === '') $e['message'] = 'Please tell us about your requirements.';
        elseif ($len($d['message']) < 10) $e['message'] = 'Please write at least 10 characters.';
        elseif ($len($d['message']) > 5000) $e['message'] = 'Message must be under 5000 characters.';

        return [$d, $e];
    }
}
