<?php
declare(strict_types=1);

namespace Silgrid;

/** Writes errors to app/storage/logs/app.log (never shown to visitors). */
final class Logger
{
    public static function error(string $message, array $context = []): void
    {
        $line = sprintf(
            "[%s] ERROR %s %s\n",
            gmdate('Y-m-d H:i:s'),
            $message,
            $context ? json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : ''
        );
        $dir = APP_DIR . '/storage/logs';
        if (is_dir($dir) && is_writable($dir)) {
            @file_put_contents($dir . '/app.log', $line, FILE_APPEND | LOCK_EX);
        } else {
            error_log(trim($line)); // falls back to the server's PHP error log
        }
    }
}
