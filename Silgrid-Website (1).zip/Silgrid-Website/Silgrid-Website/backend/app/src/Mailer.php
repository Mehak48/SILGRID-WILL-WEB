<?php
declare(strict_types=1);

namespace Silgrid;

use PHPMailer\PHPMailer\PHPMailer;

/**
 * EMAIL CONNECTOR (SMTP via PHPMailer, bundled in app/lib/PHPMailer).
 * All settings come from .env: MAIL_HOST, MAIL_PORT, MAIL_ENCRYPTION,
 * MAIL_USERNAME, MAIL_PASSWORD, MAIL_FROM_ADDRESS, MAIL_FROM_NAME, MAIL_TO_ADDRESS.
 */
final class Mailer
{
    public static function isEnabled(): bool
    {
        return Env::bool('MAIL_ENABLED');
    }

    private static function create(): PHPMailer
    {
        $mail = new PHPMailer(true); // throws exceptions on failure
        $mail->isSMTP();
        $mail->Host = Env::get('MAIL_HOST');
        $mail->Port = Env::int('MAIL_PORT', 465);
        $mail->CharSet = PHPMailer::CHARSET_UTF8;
        $mail->Timeout = 15;

        $enc = strtolower(Env::get('MAIL_ENCRYPTION', 'ssl'));
        if ($enc === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($enc === 'tls') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        } else {
            $mail->SMTPSecure = '';
            $mail->SMTPAutoTLS = false;
        }

        $user = Env::get('MAIL_USERNAME');
        if ($user !== '') {
            $mail->SMTPAuth = true;
            $mail->Username = $user;
            $mail->Password = Env::get('MAIL_PASSWORD');
        }

        $mail->setFrom(Env::get('MAIL_FROM_ADDRESS', $user), Env::get('MAIL_FROM_NAME', 'SILGRID Website'));
        foreach (array_filter(array_map('trim', explode(',', Env::get('MAIL_TO_ADDRESS')))) as $to) {
            $mail->addAddress($to);
        }
        return $mail;
    }

    /** Sends the "new enquiry" notification to the SILGRID team. Throws on failure. */
    public static function sendEnquiryNotification(array $d, ?int $id): void
    {
        $mail = self::create();
        $mail->addReplyTo($d['email'], $d['name']); // "Reply" answers the customer directly
        $mail->Subject = sprintf('New website enquiry: %s — %s', $d['service'], $d['name']);

        $h = static fn (string $s): string => htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $rows = [
            'Name' => $d['name'],
            'Email' => $d['email'],
            'Company' => $d['company'] ?: '—',
            'Phone' => $d['phone'] ?: '—',
            'Service' => $d['service'],
            'Sent from page' => $d['sourcePage'] ?: '—',
            'Reference' => $id !== null ? '#' . $id : '(not stored in database)',
        ];

        $htmlRows = '';
        $textRows = '';
        foreach ($rows as $label => $value) {
            $htmlRows .= '<tr><td style="padding:6px 16px 6px 0;color:#6b7a8c;white-space:nowrap">' . $h($label)
                . '</td><td style="padding:6px 0;color:#0F2347"><strong>' . $h($value) . '</strong></td></tr>';
            $textRows .= $label . ': ' . $value . "\n";
        }

        $mail->isHTML(true);
        $mail->Body = '<div style="font-family:Arial,sans-serif;max-width:600px">'
            . '<div style="border-top:4px solid #D4AF6A;background:#0F2347;color:#fff;padding:18px 24px;font-size:18px;font-weight:bold">New enquiry from the SILGRID website</div>'
            . '<div style="padding:20px 24px;border:1px solid #e3e8ef;border-top:0">'
            . '<table style="border-collapse:collapse;font-size:14px">' . $htmlRows . '</table>'
            . '<p style="margin:20px 0 6px;color:#6b7a8c;font-size:13px">Message</p>'
            . '<div style="white-space:pre-wrap;font-size:14px;line-height:1.6;color:#2C3E50">' . $h($d['message']) . '</div>'
            . '<p style="margin-top:24px;color:#6b7a8c;font-size:12px">Reply to this email to answer the customer directly.</p>'
            . '</div></div>';
        $mail->AltBody = "New enquiry from the SILGRID website\n\n" . $textRows . "\nMessage:\n" . $d['message'];

        $mail->send();
    }

    /** Sends a test email (used by health.php). Throws on failure. */
    public static function sendTest(): void
    {
        $mail = self::create();
        $mail->Subject = 'SILGRID website — email test';
        $mail->Body = 'If you received this, the website email settings are working.';
        $mail->send();
    }
}
