<?php
declare(strict_types=1);

namespace Silgrid;

use PDO;

/**
 * DATABASE CONNECTION (MySQL on GoDaddy)
 * Credentials come ONLY from .env: DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS.
 */
final class Database
{
    private static ?PDO $pdo = null;

    public static function isEnabled(): bool
    {
        return Env::bool('DB_ENABLED');
    }

    public static function connection(): PDO
    {
        if (self::$pdo === null) {
            $dsn = sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
                Env::get('DB_HOST', 'localhost'),
                Env::int('DB_PORT', 3306),
                Env::get('DB_NAME')
            );
            self::$pdo = new PDO($dsn, Env::get('DB_USER'), Env::get('DB_PASS'), [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_TIMEOUT => 5,
            ]);
        }
        return self::$pdo;
    }
}
