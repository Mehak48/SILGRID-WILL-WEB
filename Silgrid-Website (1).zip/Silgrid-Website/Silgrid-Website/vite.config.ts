import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite configuration — https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    // Hashed JS/CSS bundles go to /static so they never mix with the
    // replaceable files in /public/assets (images, icons, fonts, logo).
    assetsDir: 'static',
    sourcemap: false,
  },
  server: {
    port: 5173,
    // During local development, forward /api requests to the PHP dev server
    // started with `npm run backend` (http://localhost:8000).
    proxy: {
      '/api': 'http://localhost:8000',
    },
  },
});
