/**
 * Downloads the photographs used in the Figma design into public/assets/images/.
 *
 *   npm run fetch-images          → download all (overwrites placeholders)
 *   npm run fetch-images -- --skip-existing-real   (not needed normally)
 *
 * Why this exists: the project ships with lightweight placeholder images so it
 * works offline. Run this once on a machine with internet access to get the
 * exact photos from the Figma design. To use your OWN photos instead, simply
 * overwrite the files in public/assets/images/ keeping the same filenames.
 */
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const manifest = JSON.parse(await readFile(path.join(root, 'scripts/design-images.json'), 'utf8'));
const outDir = path.join(root, 'public/assets/images');

let ok = 0;
for (const img of manifest.images) {
  const url = `https://images.unsplash.com/${img.unsplashId}?w=${img.width}&h=${img.height}&fit=crop&auto=format&fm=jpg&q=78`;
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    await writeFile(path.join(outDir, img.file), buf);
    console.log(`✔ ${img.file}  (${Math.round(buf.length / 1024)} KB)`);
    ok++;
  } catch (err) {
    console.error(`✘ ${img.file}  — ${err.message}. Placeholder kept.`);
  }
}
console.log(`\n${ok}/${manifest.images.length} images downloaded to public/assets/images/`);
process.exit(ok === manifest.images.length ? 0 : 1);
