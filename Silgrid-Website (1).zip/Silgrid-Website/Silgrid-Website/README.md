# SILGRID Website

**Live domain:** https://www.silgrid.net  ·  **Owner:** SILGRID WLL, Manama, Bahrain

## ✅ Current deployment (economical setup)

| Part | Service | Cost |
|---|---|---|
| Website (static files from `dist/`) | Netlify (Free plan) | $0 |
| Contact form | Netlify Forms (`public/__forms.html`) | $0 |
| Domain + DNS | GoDaddy (DNS stays at GoDaddy) | client's domain |
| Business email (sales@, info@, accounts@) | Microsoft 365 | per licence |

**Not used in this setup:** GoDaddy hosting, PHP, MySQL. The `backend/` folder is kept
for a possible future move to PHP hosting (sections 6–8 below describe that option).

### Update the live site
1. Edit files → `npm run build`
2. Netlify → project → **Deploys** → drag the `dist` folder onto the page
3. Each deploy uses 15 of the Free plan's 300 monthly credits, so batch small changes together.

### Contact form (Netlify Forms)
- Enquiries: Netlify → project → **Forms** → `contact`
- Email notifications: Netlify → **Forms → Form notifications** (set to sales@silgrid.net)
- **Form detection must be ON** (Netlify → Forms → Enable form detection), and the site must be deployed again after turning it on.
- Do not rename or delete `public/__forms.html`. Its field names must match the popup form.

### Files Netlify uses
- `public/_redirects`: makes `/services` work on refresh
- `public/_headers`: security and caching headers
- `public/.htaccess`: only for Apache/cPanel hosting (ignored by Netlify)

---


Two-page corporate website for **SILGRID — Industrial & IT Solutions Provider**, built from the Figma Make design.

| Part | Technology | Folder |
|---|---|---|
| Website (frontend) | React 19 + Vite + TypeScript, plain CSS | `src/`, `public/` |
| Contact API (backend) | PHP 8.1+ (no Composer needed) | `backend/public/api/` |
| Private backend code, credentials, logs | PHP | `backend/app/` |
| Database | MySQL / MariaDB (GoDaddy) | `backend/database/schema.sql` |
| Email | SMTP via bundled PHPMailer | `backend/app/lib/PHPMailer/` |

Pages: **Home** (`/`) and **Services** (`/services`). A contact form popup opens from every "Get in touch", "Contact SILGRID" and "Request consultation" button.

---

## 0. Content still to complete

| What | Where to change it |
|---|---|
| Full street address (when available) | `src/config/site.ts` → `location` |
| Placeholder photos | Run `npm run fetch-images` (step 4) or add your own |

---

## 1. Install

You need **Node.js 18.18 or newer** (https://nodejs.org). For local backend testing you also need **PHP 8.1+**.

```bash
npm install
```

## 2. Run locally

**Website only** (the contact form will show "not available" because there is no backend):

```bash
npm run dev
```

Open http://localhost:5173

**Website + contact backend** (two terminals):

```bash
# Terminal 1 — PHP API on http://localhost:8000
npm run backend

# Terminal 2 — website on http://localhost:5173 (forwards /api to PHP automatically)
npm run dev
```

Then configure `backend/app/.env` (step 6/7) so the form can actually store or send enquiries.

## 3. Build for production

```bash
npm run build
```

This creates the `dist/` folder, which is the finished website ready to upload.

---

## 4. Images

All images are in **`public/assets/images/`**:

| File | Used for | Suggested size |
|---|---|---|
| `hero.jpg` | Homepage hero background | 1920×1080 |
| `about.jpg` | Homepage "About" section | 1200×900 |
| `services-hero.jpg` | Services page header background (shown at 15% opacity) | 1920×720 |
| `service-industrial.jpg` | Services page — service 01 | 1000×860 |
| `service-it-hardware.jpg` | Services page — service 02 | 1000×860 |
| `service-software.jpg` | Services page — service 03 | 1000×860 |
| `service-it-support.jpg` | Services page — service 04 | 1000×860 |
| `service-procurement.jpg` | Services page — service 05 | 1000×860 |
| `service-management.jpg` | Services page — service 06 | 1000×860 |

**The project ships with placeholder images.** To get the exact photos from the Figma design (free Unsplash licence):

```bash
npm run fetch-images
```

**To use your own image:** overwrite the file with a new one using the **same filename**. No code changes are needed, and this also works on the live server (just re-upload the file). Keep JPGs under ~300 KB for fast loading (use https://squoosh.app).

Icons are SVG files in `public/assets/icons/`. Fonts (Inter, Outfit) are self-hosted in `public/assets/fonts/`.

To use a *different filename*, edit `src/config/assets.ts`. Every image path in the site is defined in that one file.

## 5. Logo

- Header and footer logo: **`public/assets/images/logo.png`** (replace it, keeping the same name)
- Browser tab icon: **`public/assets/images/favicon.png`** (64×64 PNG)
- Logo height in the header: `src/config/site.ts` → `brand.headerLogoHeight`
- To also show the "SILGRID" text next to the logo: set `brand.showWordmarkNextToLogo: true`

Tip: a **transparent-background PNG** of the logo will look much better on the white header than the current version with a blue background.

---

## 6. Database (MySQL on GoDaddy)

### 6.1 Create the database
1. GoDaddy → **My Products → Web Hosting → Manage → cPanel Admin**
2. **MySQL® Databases**:
   - Create a database, e.g. `silgrid` (cPanel adds a prefix: `cpuser_silgrid`)
   - Create a user with a strong password
   - **Add User To Database** → tick **ALL PRIVILEGES**
3. **phpMyAdmin** → select the database → **SQL** tab → paste the contents of `backend/database/schema.sql` → **Go**

### 6.2 Add the credentials
Copy `backend/app/.env.example` to **`backend/app/.env`** and fill in:

```ini
DB_ENABLED=true
DB_HOST=localhost
DB_PORT=3306
DB_NAME=cpuser_silgrid
DB_USER=cpuser_silgriduser
DB_PASS=your-strong-password
```

`DB_HOST=localhost` is correct when the PHP files and database are on the same GoDaddy hosting account.

Enquiries are saved in the table **`contact_submissions`**. View them in phpMyAdmin. The `status` column (`new` / `in_progress` / `closed`) is there for your own tracking.

Database code lives in `backend/app/src/Database.php` and `backend/app/src/ContactRepository.php`.

## 7. Email

In the same `backend/app/.env`:

```ini
MAIL_ENABLED=true
MAIL_HOST=smtpout.secureserver.net
MAIL_PORT=465
MAIL_ENCRYPTION=ssl
MAIL_USERNAME=info@yourdomain.com
MAIL_PASSWORD=mailbox-password
MAIL_FROM_ADDRESS=info@yourdomain.com
MAIL_FROM_NAME="SILGRID Website"
MAIL_TO_ADDRESS=sales@yourdomain.com, manager@yourdomain.com
```

| Your email provider | MAIL_HOST | PORT | ENCRYPTION |
|---|---|---|---|
| GoDaddy Professional Email | `smtpout.secureserver.net` | 465 | ssl |
| Microsoft 365 (via GoDaddy) | `smtp.office365.com` | 587 | tls |
| cPanel email account | `mail.yourdomain.com` | 465 | ssl |

- `MAIL_FROM_ADDRESS` should normally be the **same mailbox** as `MAIL_USERNAME`, or the server may reject it.
- Each notification has **Reply-To set to the customer**, so pressing "Reply" answers them directly.
- Microsoft 365 needs **SMTP AUTH enabled** for that mailbox (Microsoft 365 admin → Users → Mail → Manage email apps).

Email code lives in `backend/app/src/Mailer.php`.

### How the form decides success
The visitor only sees "Thank you" when the enquiry **actually reached you**:

| Database | Email | Result shown to visitor |
|---|---|---|
| ✔ saved | ✔ sent | Success |
| ✔ saved | ✘ failed | Success (saved; `email_sent = 0` in DB, error logged) |
| ✘ failed | ✔ sent | Success (emailed; error logged) |
| ✘ failed | ✘ failed | Error + your email address as fallback |
| both disabled | | "Contact form is being set up" |

Errors are logged in `backend/app/storage/logs/app.log`. Passwords are never logged.

---

## 8. Deploy to GoDaddy (cPanel)

Final server layout:

```text
/home/USERNAME/
├── app/                 ← contents of backend/app/  (PRIVATE, includes .env)
└── public_html/
    ├── index.html       ← contents of dist/
    ├── .htaccess        ← from dist/ (hidden file — make sure it uploads)
    ├── assets/  static/  robots.txt
    └── api/             ← contents of backend/public/api/
        ├── contact.php
        ├── health.php
        ├── app-path.php
        └── .htaccess
```

Steps:
1. Run `npm run build`
2. cPanel → **File Manager** → open `public_html` → upload everything **inside** `dist/`. In File Manager Settings, tick **Show Hidden Files** so you can confirm `.htaccess` is there.
3. Create `public_html/api/` and upload the files from `backend/public/api/`
4. Go **one level up** from `public_html` (your home folder) and upload the `backend/app/` folder there, so you have `/home/USERNAME/app/`
5. Create `/home/USERNAME/app/.env` from `.env.example` and fill it in (steps 6 and 7)
6. Make sure `app/storage/logs` and `app/storage/ratelimit` are writable (permissions **755**; use 775 only if logging fails)
7. cPanel → **MultiPHP Manager**: set PHP **8.1 or newer**. Check that the `pdo_mysql` and `openssl` extensions are enabled (Select PHP Version → Extensions).
8. Turn on SSL, then uncomment the "Force HTTPS" lines in `public_html/.htaccess`

If you must put `app/` somewhere else, edit the path in `api/app-path.php`.

### Test after deploying
Set a long random `HEALTH_CHECK_TOKEN` in `.env`, then open:

```
https://yourdomain.com/api/health.php?token=YOUR_TOKEN
https://yourdomain.com/api/health.php?token=YOUR_TOKEN&send_test_email=1
```

You should see `"connected": true`, `"table_exists": true`, and `"test_email_sent": true`. **Clear the token afterwards** to switch the check off.

Then send a real enquiry through the website and check both the email and phpMyAdmin.

### Updating the site later
- Text or layout changed → `npm run build` → re-upload `dist/` contents (keep `api/` untouched)
- Image changed → just re-upload that one image file into `public_html/assets/images/`

---

## 9. Other configuration

| Setting | File |
|---|---|
| Contact API URL (only if the API is on another domain) | `.env` in project root → `VITE_CONTACT_ENDPOINT`, then rebuild |
| Allowed other domains for the API (CORS) | `backend/app/.env` → `ALLOWED_ORIGINS` |
| Spam limit (messages per visitor per hour) | `backend/app/.env` → `RATE_LIMIT_MAX`, `RATE_LIMIT_WINDOW_SECONDS` |
| Contact form dropdown options | `src/data/content.ts` **and** `backend/app/config.php` (keep them identical) |
| Page titles | `src/App.tsx` |
| SEO description / social preview | `index.html` |
| Colours and spacing | `src/styles/tokens.css` |

## 10. Project structure

```text
Silgrid-Website/
├── public/                     Copied as-is into the build
│   ├── assets/images/          Logo, favicon, photos (replace freely)
│   ├── assets/icons/           SVG icons
│   ├── assets/fonts/           Inter + Outfit (self-hosted)
│   ├── .htaccess               Apache: page routing, security, caching
│   └── robots.txt
├── src/
│   ├── config/assets.ts        Every image/icon path
│   ├── config/site.ts          Company details, logo settings
│   ├── data/content.ts         All website text
│   ├── lib/router.tsx          Page navigation (/ and /services)
│   ├── lib/api.ts              The ONLY place that calls the backend
│   ├── lib/validation.ts       Form validation rules
│   ├── components/layout/      Nav, Footer
│   ├── components/ui/          Button, SectionHeading
│   ├── components/cards/       ServiceCard, IndustryTag
│   ├── components/contact/     Contact popup + form
│   ├── pages/                  HomePage, ServicesPage, NotFoundPage
│   └── styles/                 Global CSS, design tokens, fonts
├── backend/
│   ├── public/api/             Public endpoints (contact.php, health.php)
│   ├── app/                    PRIVATE: code, .env, logs, PHPMailer
│   └── database/schema.sql     MySQL table
├── scripts/                    Figma image downloader
├── .env.example                Frontend settings (no secrets)
└── package.json
```

## Security notes
- No credentials exist in frontend code. Everything secret is in `backend/app/.env`, stored outside `public_html`.
- `backend/app/.htaccess` blocks web access even if the folder is uploaded to the wrong place.
- The form is protected by server-side validation, a hidden bot trap, rate limiting per visitor, prepared SQL statements, and HTML escaping in emails.
- Visitor IP addresses are stored only as SHA-256 hashes.
- Never commit `.env` files (they're already in `.gitignore`).

## Third-party licences
- Inter and Outfit fonts: SIL Open Font License (`public/assets/fonts/`)
- PHPMailer: LGPL 2.1 (`backend/app/lib/PHPMailer/LICENSE`)
- Figma photos (via `fetch-images`): Unsplash License
