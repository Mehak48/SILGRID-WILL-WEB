/**
 * Global "open the contact form" capability.
 * Any component can call:  const { openContact } = useContact();
 *                          openContact('Software & Licensing Services');
 * The optional argument pre-selects a service in the dropdown.
 */
import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import { ContactModal } from './ContactModal';

interface ContactContextValue {
  openContact: (service?: string) => void;
}

const ContactContext = createContext<ContactContextValue | null>(null);

export function ContactProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [presetService, setPresetService] = useState('');
  // Changing the key gives every opening a fresh, empty form
  const [formKey, setFormKey] = useState(0);

  const openContact = useCallback((service?: string) => {
    setPresetService(service ?? '');
    setFormKey((k) => k + 1);
    setOpen(true);
  }, []);

  return (
    <ContactContext.Provider value={{ openContact }}>
      {children}
      {open && <ContactModal key={formKey} presetService={presetService} onClose={() => setOpen(false)} />}
    </ContactContext.Provider>
  );
}

export function useContact(): ContactContextValue {
  const ctx = useContext(ContactContext);
  if (!ctx) throw new Error('useContact must be used inside <ContactProvider>');
  return ctx;
}
