import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Eyebrow } from '../ui/SectionHeading';
import { ContactForm } from './ContactForm';
import './Contact.css';

interface Props {
  presetService: string;
  onClose: () => void;
}

/** Accessible modal dialog: Esc to close, focus trap, scroll lock, focus restore. */
export function ContactModal({ presetService, onClose }: Props) {
  const panelRef = useRef<HTMLDivElement>(null);
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(busy);
  busyRef.current = busy;

  useEffect(() => {
    const previouslyFocused = document.activeElement as HTMLElement | null;
    const scrollbarGap = window.innerWidth - document.documentElement.clientWidth;
    document.body.style.overflow = 'hidden';
    document.body.style.paddingRight = `${scrollbarGap}px`;

    // Focus the first form field
    requestAnimationFrame(() => panelRef.current?.querySelector<HTMLElement>('input, select, textarea')?.focus());

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !busyRef.current) onClose();
      if (e.key === 'Tab' && panelRef.current) {
        const focusables = panelRef.current.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), input:not([disabled]):not([tabindex="-1"]), select:not([disabled]), textarea:not([disabled])',
        );
        if (!focusables.length) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);

    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
      previouslyFocused?.focus?.();
    };
  }, [onClose]);

  return createPortal(
    <div
      className="contact-modal"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget && !busy) onClose();
      }}
    >
      <div
        ref={panelRef}
        className="contact-modal__panel"
        role="dialog"
        aria-modal="true"
        aria-labelledby="contact-modal-title"
      >
        <button type="button" className="contact-modal__close" onClick={onClose} disabled={busy} aria-label="Close">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>
        <Eyebrow label="Get in touch" lineWidth={28} small />
        <h2 id="contact-modal-title" className="contact-modal__title">
          Contact SILGRID
        </h2>
        <p className="contact-modal__intro">
          Tell us about your industrial materials, IT, or procurement requirements. We respond within one business
          day.
        </p>
        <ContactForm presetService={presetService} onBusyChange={setBusy} onDone={onClose} />
      </div>
    </div>,
    document.body,
  );
}
