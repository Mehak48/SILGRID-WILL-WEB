import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import { site } from '../../config/site';
import { contactServiceOptions } from '../../data/content';
import { submitContact } from '../../lib/api';
import { useRouter } from '../../lib/router';
import { LIMITS, validateContact, type ContactFormValues, type FieldErrors } from '../../lib/validation';

type Status = 'idle' | 'submitting' | 'success' | 'error' | 'mailto';

interface Props {
  presetService?: string;
  onBusyChange?: (busy: boolean) => void;
  onDone?: () => void;
}

const EMPTY: ContactFormValues = { name: '', email: '', company: '', phone: '', service: '', message: '' };

export function ContactForm({ presetService = '', onBusyChange, onDone }: Props) {
  const { location } = useRouter();
  const [values, setValues] = useState<ContactFormValues>({
    ...EMPTY,
    service: contactServiceOptions.includes(presetService) ? presetService : '',
  });
  const [honeypot, setHoneypot] = useState('');
  const [errors, setErrors] = useState<FieldErrors>({});
  const [touched, setTouched] = useState<Partial<Record<keyof ContactFormValues, boolean>>>({});
  const [status, setStatus] = useState<Status>('idle');
  const [serverMessage, setServerMessage] = useState('');
  const [showEmailFallback, setShowEmailFallback] = useState(false);

  useEffect(() => onBusyChange?.(status === 'submitting'), [status, onBusyChange]);

  const update = (field: keyof ContactFormValues) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const next = { ...values, [field]: e.target.value };
    setValues(next);
    // Re-validate a field live once the user has already left it
    if (touched[field]) setErrors((prev) => ({ ...prev, [field]: validateContact(next, contactServiceOptions)[field] }));
  };

  const blur = (field: keyof ContactFormValues) => () => {
    setTouched((t) => ({ ...t, [field]: true }));
    setErrors((prev) => ({ ...prev, [field]: validateContact(values, contactServiceOptions)[field] }));
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (status === 'submitting') return;

    const clientErrors = validateContact(values, contactServiceOptions);
    setTouched({ name: true, email: true, company: true, phone: true, service: true, message: true });
    setErrors(clientErrors);
    if (Object.keys(clientErrors).length) {
      const first = Object.keys(clientErrors)[0];
      document.getElementById(`contact-${first}`)?.focus();
      return;
    }

    // Email-only mode: open the visitor's email app with the enquiry filled in.
    if (site.contactEndpoint === 'mailto') {
      const lines = [`Name: ${values.name.trim()}`, `Email: ${values.email.trim()}`];
      if (values.company.trim()) lines.push(`Company: ${values.company.trim()}`);
      if (values.phone.trim()) lines.push(`Phone: ${values.phone.trim()}`);
      lines.push(`Service: ${values.service}`, '', values.message.trim());
      const body = lines.join('\n');
      const subject = `Website enquiry: ${values.service}`;
      window.location.href = `mailto:${site.contact.salesEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      setStatus('mailto');
      return;
    }

    setStatus('submitting');
    setServerMessage('');
    const result = await submitContact({
      name: values.name.trim(),
      email: values.email.trim(),
      company: values.company.trim(),
      phone: values.phone.trim(),
      service: values.service,
      message: values.message.trim(),
      website: honeypot,
      sourcePage: location.path,
    });

    if (result.ok) {
      setStatus('success');
      return;
    }
    setStatus('error');
    setServerMessage(result.message);
    setShowEmailFallback(result.kind !== 'validation' && result.kind !== 'rate_limited');
    if (result.fieldErrors) setErrors(result.fieldErrors);
  };

  if (status === 'mailto') {
    return (
      <div className="contact-success" role="status">
        <h3 className="contact-success__title">Your email app should now be open.</h3>
        <p className="contact-success__text">
          Your enquiry is ready in a new email. Press <strong>Send</strong> there to reach our team.
        </p>
        <p className="contact-success__text">
          If no email app opened, please email us directly at{' '}
          <a href={`mailto:${site.contact.salesEmail}`}>
            <strong>{site.contact.salesEmail}</strong>
          </a>
          .
        </p>
        {onDone && (
          <button type="button" className="btn btn--solid btn--size-md" onClick={onDone}>
            CLOSE
          </button>
        )}
      </div>
    );
  }

  if (status === 'success') {
    return (
      <div className="contact-success" role="status">
        <svg width="50" height="50" viewBox="0 0 50 50" fill="none" stroke="#D4AF6A" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <circle cx="25" cy="25" r="18" />
          <polyline points="16,25 22,31 34,19" />
        </svg>
        <h3 className="contact-success__title">Thank you, your enquiry has been received.</h3>
        <p className="contact-success__text">
          A member of our team will contact you at <strong>{values.email.trim()}</strong> within one business day.
        </p>
        {onDone && (
          <button type="button" className="btn btn--solid btn--size-md" onClick={onDone}>
            CLOSE
          </button>
        )}
      </div>
    );
  }

  const fieldProps = (field: keyof ContactFormValues) => ({
    id: `contact-${field}`,
    name: field,
    value: values[field],
    onChange: update(field),
    onBlur: blur(field),
    'aria-invalid': Boolean(errors[field]) || undefined,
    'aria-describedby': errors[field] ? `contact-${field}-error` : undefined,
    disabled: status === 'submitting',
  });

  const errorText = (field: keyof ContactFormValues) =>
    errors[field] ? (
      <span className="contact-field__error" id={`contact-${field}-error`}>
        {errors[field]}
      </span>
    ) : null;

  return (
    <form className="contact-form" onSubmit={onSubmit} noValidate>
      <div className="contact-form__grid">
        <label className="contact-field">
          <span className="contact-field__label">
            Full name <span aria-hidden="true">*</span>
          </span>
          <input type="text" autoComplete="name" maxLength={LIMITS.nameMax} required {...fieldProps('name')} />
          {errorText('name')}
        </label>

        <label className="contact-field">
          <span className="contact-field__label">
            Email address <span aria-hidden="true">*</span>
          </span>
          <input type="email" autoComplete="email" maxLength={LIMITS.emailMax} required {...fieldProps('email')} />
          {errorText('email')}
        </label>

        <label className="contact-field">
          <span className="contact-field__label">Company</span>
          <input type="text" autoComplete="organization" maxLength={LIMITS.companyMax} {...fieldProps('company')} />
          {errorText('company')}
        </label>

        <label className="contact-field">
          <span className="contact-field__label">Phone</span>
          <input type="tel" autoComplete="tel" maxLength={LIMITS.phoneMax} {...fieldProps('phone')} />
          {errorText('phone')}
        </label>

        <label className="contact-field contact-field--full">
          <span className="contact-field__label">
            Service of interest <span aria-hidden="true">*</span>
          </span>
          <select required {...fieldProps('service')}>
            <option value="" disabled>
              Select a service…
            </option>
            {contactServiceOptions.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
          {errorText('service')}
        </label>

        <label className="contact-field contact-field--full">
          <span className="contact-field__label">
            Your requirements <span aria-hidden="true">*</span>
          </span>
          <textarea rows={5} maxLength={LIMITS.messageMax} required {...fieldProps('message')} />
          {errorText('message')}
        </label>
      </div>

      {/* Honeypot anti-spam field: hidden from people, filled in by bots */}
      <div className="visually-hidden" aria-hidden="true">
        <label>
          Leave this field empty
          <input type="text" name="website" tabIndex={-1} autoComplete="off" value={honeypot} onChange={(e) => setHoneypot(e.target.value)} />
        </label>
      </div>

      {status === 'error' && (
        <div className="contact-form__alert" role="alert">
          <p>{serverMessage}</p>
          {showEmailFallback && (
            <p>
              You can also email us directly at{' '}
              <a href={`mailto:${site.contact.email}`}>{site.contact.email}</a>.
            </p>
          )}
        </div>
      )}

      <div className="contact-form__footer">
        <p className="contact-form__note">* Required fields</p>
        <button type="submit" className="btn btn--solid btn--size-lg" disabled={status === 'submitting'}>
          {status === 'submitting' ? (
            <>
              <span className="contact-form__spinner" aria-hidden="true" /> SENDING…
            </>
          ) : site.contactEndpoint === 'mailto' ? (
            'SEND BY EMAIL'
          ) : (
            'SEND ENQUIRY'
          )}
        </button>
      </div>
    </form>
  );
}
