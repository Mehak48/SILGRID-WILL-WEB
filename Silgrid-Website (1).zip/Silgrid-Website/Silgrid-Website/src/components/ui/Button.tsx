import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { Link } from '../../lib/router';
import './Button.css';

/**
 * Button variants reproduced from the Figma design:
 *  hero-primary  – navy with faint white border (hero "Explore our services")
 *  hero-ghost    – transparent, white border (hero "Contact us")
 *  outline       – navy outline, fills navy on hover ("Our services")
 *  solid         – navy, gold border on hover ("Request consultation")
 *  solid-plain   – navy, darkens on hover ("Request a consultation")
 *  gold          – gold call-to-action ("Contact SILGRID")
 *  nav           – compact navy button in the navigation bar ("Get in touch")
 */
export type ButtonVariant = 'hero-primary' | 'hero-ghost' | 'outline' | 'solid' | 'solid-plain' | 'gold' | 'nav';
export type ButtonSize = 'md' | 'lg' | 'xl' | 'cta';

interface Props extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
  variant: ButtonVariant;
  size?: ButtonSize;
  /** If set, renders a navigation link instead of a <button>. */
  to?: string;
  children: ReactNode;
}

export function Button({ variant, size = 'md', to, className = '', children, ...rest }: Props) {
  const cls = `btn btn--${variant} btn--size-${size} ${className}`.trim();
  if (to) {
    return (
      <Link to={to} className={cls}>
        {children}
      </Link>
    );
  }
  return (
    <button type="button" className={cls} {...rest}>
      {children}
    </button>
  );
}
