import './SectionHeading.css';

interface EyebrowProps {
  label: string;
  /** "left": line + text. "center": line + text + line. */
  align?: 'left' | 'center';
  lineWidth?: number;
  small?: boolean;
  className?: string;
}

/** Small gold label with a gold line — used above most headings in the Figma design. */
export function Eyebrow({ label, align = 'left', lineWidth = 32, small = false, className = '' }: EyebrowProps) {
  const line = <span className="eyebrow__line" style={{ width: lineWidth }} aria-hidden="true" />;
  return (
    <div className={`eyebrow eyebrow--${align} ${small ? 'eyebrow--small' : ''} ${className}`.trim()}>
      {line}
      <span className="eyebrow__label">{label}</span>
      {align === 'center' && line}
    </div>
  );
}

interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  id?: string;
}

/** Centered section heading: eyebrow, title and short gold divider. */
export function SectionHeading({ eyebrow, title, id }: SectionHeadingProps) {
  return (
    <div className="section-heading">
      <Eyebrow label={eyebrow} align="center" />
      <h2 className="section-heading__title" id={id}>
        {title}
      </h2>
      <div className="section-heading__divider" aria-hidden="true" />
    </div>
  );
}
