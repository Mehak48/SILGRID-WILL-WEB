import { Link } from '../../lib/router';
import type { Service } from '../../data/content';
import './Cards.css';

/** Homepage service card with gold top border and hover lift (Figma). */
export function ServiceCard({ service }: { service: Service }) {
  return (
    <article className="service-card">
      <img src={service.icon} alt="" className="service-card__icon" width={40} height={40} loading="lazy" />
      <h3 className="service-card__title">{service.cardTitle}</h3>
      <p className="service-card__desc">{service.cardDescription}</p>
      <Link to={`/services#${service.id}`} className="service-card__link" aria-label={`Learn more about ${service.cardTitle}`}>
        LEARN MORE
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
          <path d="M2 7h10M8 3l4 4-4 4" />
        </svg>
      </Link>
    </article>
  );
}
