import './Cards.css';

/** Circular industry icon that turns navy/gold on hover (Figma). */
export function IndustryTag({ icon, label }: { icon: string; label: string }) {
  return (
    <li className="industry-tag">
      <span className="industry-tag__circle">
        <img src={icon} alt="" className="industry-tag__icon" width={40} height={40} loading="lazy" />
      </span>
      <span className="industry-tag__label">{label}</span>
    </li>
  );
}
