import { images } from '../../config/assets';
import { site } from '../../config/site';
import { services } from '../../data/content';
import { Link } from '../../lib/router';
import { navLinks } from './navLinks';
import './Footer.css';

export function Footer() {
  const year = new Date().getFullYear();
  const telHref = `tel:${site.contact.phone.replace(/[^+0-9]/g, '')}`;

  return (
    <footer className="footer">
      <div className="footer__grid">
        <div>
          <Link to="/" className="footer__brand" aria-label={`${site.name} — home`}>
            <img src={images.logo} alt={site.name} className="footer__logo" loading="lazy" width={100} height={80} />
          </Link>
          <p className="footer__desc">{site.footerDescription}</p>
        </div>

        <div>
          <h2 className="footer__heading">Navigation</h2>
          <ul>
            {navLinks.map((item) => (
              <li key={item.label}>
                <Link to={item.to} className="footer__link">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="footer__heading">Services</h2>
          <ul>
            {services.map((s) => (
              <li key={s.id}>
                <Link to={`/services#${s.id}`} className="footer__link">
                  {s.shortTitle}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="footer__heading">Contact</h2>
          <address className="footer__contact">
            <a href={`mailto:${site.contact.salesEmail}`} className="footer__link footer__link--inline">
              Sales: {site.contact.salesEmail}
            </a>
            <a href={`mailto:${site.contact.email}`} className="footer__link footer__link--inline">
              Support: {site.contact.email}
            </a>
            <a href={telHref} className="footer__link footer__link--inline">
              {site.contact.phone}
            </a>
            <span>
              {site.contact.address.map((line) => (
                <span key={line}>
                  {line}
                  <br />
                </span>
              ))}
            </span>
          </address>
        </div>
      </div>

      <div className="footer__bottom">
        <p>
          © {year} {site.legalName}. All rights reserved.
        </p>
        <p>Industrial Materials · IT Solutions · Technology Procurement</p>
      </div>
    </footer>
  );
}
