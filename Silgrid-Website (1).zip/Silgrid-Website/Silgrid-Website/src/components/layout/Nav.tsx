import { useEffect, useRef, useState } from 'react';
import { images } from '../../config/assets';
import { site } from '../../config/site';
import { Link, useRouter } from '../../lib/router';
import { useContact } from '../contact/ContactProvider';
import { navLinks } from './navLinks';
import './Nav.css';

export function Nav() {
  const { location } = useRouter();
  const { openContact } = useContact();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  // Stronger shadow once the page is scrolled (Figma interaction)
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Close the mobile menu on navigation, Escape key, outside click, or resize to desktop
  useEffect(() => setMenuOpen(false), [location.key]);
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setMenuOpen(false);
    const onClick = (e: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    const onResize = () => window.innerWidth > 768 && setMenuOpen(false);
    document.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onClick);
    window.addEventListener('resize', onResize);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onClick);
      window.removeEventListener('resize', onResize);
    };
  }, [menuOpen]);

  const isActive = (activeOn: string | null) => activeOn !== null && location.path === activeOn;

  return (
    <nav ref={navRef} className={`nav ${scrolled ? 'nav--scrolled' : ''}`} aria-label="Main">
      <Link to="/" className="nav__brand" aria-label={`${site.name} — home`}>
        <span className="nav__logo-wrap">
          <img src={images.logo} alt="" className="nav__logo" width={56} height={45} />
        </span>
        {site.brand.showWordmarkNextToLogo && (
          <span className="nav__brand-text">
            <span className="nav__wordmark">{site.name}</span>
            <span className="nav__tagline" title={`${site.fullName} (${site.name})`}>
              {/* First letter of each word is highlighted: S·I·L·G·R·I·D */}
              {site.fullName.split(' ').map((word, i) =>
                /^[A-Za-z]/.test(word) ? (
                  <span key={i}>
                    <span className="nav__initial">{word[0]}</span>
                    {word.slice(1)}{' '}
                  </span>
                ) : (
                  <span key={i}>{word} </span>
                ),
              )}
            </span>
          </span>
        )}
      </Link>

      {/* Desktop menu */}
      <div className="nav__desktop">
        {navLinks.map((item) => (
          <Link
            key={item.label}
            to={item.to}
            className={`nav__link ${isActive(item.activeOn) ? 'nav__link--active' : ''}`}
            aria-current={isActive(item.activeOn) ? 'page' : undefined}
          >
            {item.label}
          </Link>
        ))}
        <button type="button" className="btn btn--nav" onClick={() => openContact()}>
          GET IN TOUCH
        </button>
      </div>

      {/* Mobile hamburger */}
      <button
        type="button"
        className="nav__toggle"
        aria-label={menuOpen ? 'Close menu' : 'Open menu'}
        aria-expanded={menuOpen}
        aria-controls="mobile-menu"
        onClick={() => setMenuOpen((o) => !o)}
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#0F2347" strokeWidth="2" strokeLinecap="round">
          {menuOpen ? (
            <>
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </>
          ) : (
            <>
              <line x1="4" y1="8" x2="20" y2="8" />
              <line x1="4" y1="14" x2="20" y2="14" />
              <line x1="4" y1="20" x2="20" y2="20" />
            </>
          )}
        </svg>
      </button>

      {/* Mobile dropdown */}
      <div id="mobile-menu" className={`nav__mobile ${menuOpen ? 'nav__mobile--open' : ''}`} hidden={!menuOpen}>
        {navLinks.map((item) => (
          <Link
            key={item.label}
            to={item.to}
            className={`nav__mobile-link ${isActive(item.activeOn) ? 'nav__mobile-link--active' : ''}`}
          >
            {item.label}
          </Link>
        ))}
        <button
          type="button"
          className="btn btn--nav nav__mobile-cta"
          onClick={() => {
            setMenuOpen(false);
            openContact();
          }}
        >
          GET IN TOUCH
        </button>
      </div>
    </nav>
  );
}
