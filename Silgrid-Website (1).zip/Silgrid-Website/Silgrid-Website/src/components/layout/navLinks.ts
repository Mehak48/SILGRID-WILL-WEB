/** Main navigation items (shared by header and footer). */
export const navLinks = [
  { label: 'Home', to: '/', activeOn: '/' },
  { label: 'Services', to: '/services', activeOn: '/services' },
  { label: 'About', to: '/#about', activeOn: null },
  { label: 'Contact', to: '/#contact', activeOn: null },
] as const;
