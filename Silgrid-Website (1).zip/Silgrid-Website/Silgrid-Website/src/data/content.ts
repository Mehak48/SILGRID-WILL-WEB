/**
 * WEBSITE TEXT CONTENT
 * ─────────────────────────────────────────────────────────────
 * All copy from the Figma design lives here, separate from layout code,
 * so text can be edited without touching components.
 *
 * Client instruction: no numerical claims (years, supplier counts,
 * countries). The highlights bar uses general wording instead.
 */
import { icons, images } from '../config/assets';

export type ServiceId =
  | 'industrial'
  | 'it-hardware'
  | 'software'
  | 'it-support'
  | 'procurement'
  | 'management';

export interface Service {
  id: ServiceId;
  /** Short name used in the footer and the contact form dropdown. */
  shortTitle: string;
  /** Title on the homepage service card. */
  cardTitle: string;
  /** Title on the Services page. */
  pageTitle: string;
  cardDescription: string;
  pageBody: string;
  bullets: string[];
  icon: string;
  image: string;
  imageAlt: string;
}

export const services: Service[] = [
  {
    id: 'industrial',
    shortTitle: 'Industrial Materials',
    cardTitle: 'Industrial Materials & Technical Supplies',
    pageTitle: 'Industrial Materials & Technical Supplies',
    cardDescription:
      'Comprehensive sourcing and supply of industrial materials, components, and technical equipment for demanding operational environments.',
    pageBody:
      'SILGRID maintains an extensive global supplier network to source and deliver industrial materials and technical components for projects of any scale. From structural steel and piping systems to specialist consumables and MRO supplies, we deliver quality-assured products with full traceability and compliance documentation.',
    bullets: [
      'Structural materials, piping, and mechanical components',
      'MRO consumables and specialist industrial supplies',
      'Quality-assured sourcing with full compliance documentation',
      'Expedited procurement for critical and time-sensitive projects',
    ],
    icon: icons.industrial,
    image: images.serviceIndustrial,
    imageAlt: 'Industrial factory interior with steel structures and heavy equipment',
  },
  {
    id: 'it-hardware',
    shortTitle: 'IT Hardware',
    cardTitle: 'IT Hardware & Technology Solutions',
    pageTitle: 'IT Hardware & Technology Solutions',
    cardDescription:
      'Enterprise-grade hardware procurement, deployment, and lifecycle management for organizations of every scale.',
    pageBody:
      'We procure, configure, and deploy enterprise-grade IT hardware across complex technical environments. From data centre infrastructure to end-user devices and networking equipment, our team manages the entire procurement and deployment lifecycle to minimise operational disruption.',
    bullets: [
      'Servers, storage systems, and networking infrastructure',
      'End-user computing devices and peripheral equipment',
      'Data centre design, procurement, and deployment support',
      'Hardware lifecycle management and asset tracking',
    ],
    icon: icons.itHardware,
    image: images.serviceItHardware,
    imageAlt: 'Cable network and server infrastructure in a data centre',
  },
  {
    id: 'software',
    shortTitle: 'Software & Licensing',
    cardTitle: 'Software & Licensing',
    pageTitle: 'Software & Licensing Services',
    cardDescription:
      'Strategic software procurement, license management, and compliance services across leading technology vendors.',
    pageBody:
      'Navigating enterprise software procurement requires expertise across vendor relationships, licensing models, and compliance frameworks. SILGRID simplifies the process, securing competitive pricing on industry-leading platforms while ensuring your organisation remains fully compliant and optimally licensed.',
    bullets: [
      'Enterprise software procurement across major vendors',
      'Volume and true-up license management',
      'Software Asset Management (SAM) consultancy',
      'Cloud subscription and SaaS agreement management',
    ],
    icon: icons.software,
    image: images.serviceSoftware,
    imageAlt: 'Two developers working at computer monitors in a professional office environment',
  },
  {
    id: 'it-support',
    shortTitle: 'IT Consultancy',
    cardTitle: 'IT Support & Consultancy',
    pageTitle: 'IT Support & Consultancy',
    cardDescription:
      'Specialist technical consultancy and on-site support, delivered by industry professionals with deep sectoral expertise.',
    pageBody:
      'Our specialist consultancy team works alongside your internal teams to design, implement, and support technology systems in technically demanding environments. We bring deep sector knowledge across oil and gas, energy, aviation, and industrial operations.',
    bullets: [
      'On-site and remote technical support provision',
      'Infrastructure design and systems architecture consultancy',
      'Technology roadmap planning and strategic advisory',
      'Staff augmentation and specialist resource deployment',
    ],
    icon: icons.itSupport,
    image: images.serviceItSupport,
    imageAlt: 'Professional team collaborating at a meeting table with laptops',
  },
  {
    id: 'procurement',
    shortTitle: 'Procurement',
    cardTitle: 'Procurement & Supply Chain',
    pageTitle: 'Procurement & Supply Chain',
    cardDescription:
      'End-to-end procurement management with global supplier networks, cost optimization, and transparent delivery tracking.',
    pageBody:
      'SILGRID provides end-to-end procurement management services, from supplier identification and qualification through to delivery and performance monitoring. Our global supplier network and established logistics partnerships ensure reliable supply even for complex, multi-geography projects.',
    bullets: [
      'Global supplier identification, qualification, and management',
      'Purchase order management and expediting',
      'Customs, freight, and last-mile logistics coordination',
      'Supply chain risk assessment and contingency planning',
    ],
    icon: icons.procurement,
    image: images.serviceProcurement,
    imageAlt: 'Aerial view of shipping container yard representing global logistics and supply chain operations',
  },
  {
    id: 'management',
    shortTitle: 'Facility Support',
    cardTitle: 'Management & Facility Support',
    pageTitle: 'Management & Facility Support',
    cardDescription:
      'Integrated facility management, operational support, and maintenance services to keep your operations running reliably.',
    pageBody:
      'Maintaining operational continuity across technical facilities demands reliable, experienced support. SILGRID delivers integrated facility management and operational support services that keep your assets performing, your teams equipped, and your operations on schedule.',
    bullets: [
      'Planned and reactive maintenance programme management',
      'Facilities operations and soft services coordination',
      'Asset management, condition monitoring, and reporting',
      'Operational continuity planning and support deployment',
    ],
    icon: icons.management,
    image: images.serviceManagement,
    imageAlt: 'Server room with rack of servers representing managed infrastructure and facility operations',
  },
];

/**
 * Options for the contact form "Service of interest" dropdown.
 * ⚠ Must match ALLOWED_SERVICES in backend/app/config.php.
 */
export const contactServiceOptions: string[] = [
  ...services.map((s) => s.pageTitle),
  'General Enquiry',
];

/** Highlights bar under the hero (word-based, no numerical claims). */
export const stats = [
  { value: 'Global', label: 'Serving Clients Worldwide' },
  { value: 'Reliable', label: 'Quality-Assured Sourcing' },
  { value: 'Integrated', label: 'Industrial & IT Solutions' },
  { value: 'Responsive', label: 'Dedicated Client Support' },
];

export const industries = [
  { icon: icons.manufacturing, label: 'Industrial & Manufacturing' },
  { icon: icons.oilGas, label: 'Oil & Gas' },
  { icon: icons.energy, label: 'Energy' },
  { icon: icons.engineering, label: 'Engineering' },
  { icon: icons.construction, label: 'Construction' },
  { icon: icons.aviation, label: 'Aviation' },
  { icon: icons.technology, label: 'Technology & IT' },
];

export const whyUs = [
  {
    icon: icons.reliableSourcing,
    title: 'Reliable Sourcing',
    desc: 'Trusted supply chain partnerships spanning global markets, ensuring availability and consistent quality at every order volume.',
  },
  {
    icon: icons.technicalExpertise,
    title: 'Technical Expertise',
    desc: 'Industry specialists with deep domain knowledge guiding procurement decisions across materials, IT, and operations.',
  },
  {
    icon: icons.integratedSolutions,
    title: 'Integrated Solutions',
    desc: 'Seamlessly unified industrial materials, IT infrastructure, and support services under a single accountable partner.',
  },
  {
    icon: icons.professionalSupport,
    title: 'Professional Support',
    desc: 'Dedicated consultancy, responsive on-site assistance, and proactive account management throughout the engagement lifecycle.',
  },
];
