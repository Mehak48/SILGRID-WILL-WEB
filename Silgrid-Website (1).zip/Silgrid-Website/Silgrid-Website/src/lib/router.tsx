/**
 * Minimal client-side router (no external dependency).
 *
 * Routes:  "/"          → Home page
 *          "/services"  → Services page
 * Hash links such as "/#about" or "/services#software" scroll to a section.
 *
 * Real URLs are used (not "#/services"), so pages can be bookmarked and shared.
 * On Apache/GoDaddy, public/.htaccess sends unknown paths to index.html.
 */
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type AnchorHTMLAttributes,
  type MouseEvent,
  type ReactNode,
} from 'react';

export type RoutePath = '/' | '/services' | '404';

interface Location {
  path: RoutePath;
  hash: string;
  /** Increments on every navigation so repeated clicks on the same link still scroll. */
  key: number;
  /** True when navigation stayed on the same page (smooth-scroll) */
  samePage: boolean;
}

interface RouterValue {
  location: Location;
  navigate: (to: string) => void;
}

const RouterContext = createContext<RouterValue | null>(null);

function normalizePath(pathname: string): RoutePath {
  const p = pathname.replace(/\/+$/, '') || '/';
  if (p === '/' || p === '/index.html') return '/';
  if (p === '/services') return '/services';
  return '404';
}

function parse(to: string): { pathname: string; hash: string } {
  const url = new URL(to, window.location.origin);
  return { pathname: url.pathname, hash: url.hash.replace(/^#/, '') };
}

export function RouterProvider({ children }: { children: ReactNode }) {
  const [location, setLocation] = useState<Location>(() => ({
    path: normalizePath(window.location.pathname),
    hash: window.location.hash.replace(/^#/, ''),
    key: 0,
    samePage: false,
  }));

  const navigate = useCallback((to: string) => {
    const { pathname, hash } = parse(to);
    const nextPath = normalizePath(pathname);
    const url = pathname + (hash ? `#${hash}` : '');
    if (url !== window.location.pathname + window.location.hash) {
      window.history.pushState(null, '', url);
    }
    setLocation((prev) => ({
      path: nextPath,
      hash,
      key: prev.key + 1,
      samePage: prev.path === nextPath,
    }));
  }, []);

  // Browser back/forward buttons
  useEffect(() => {
    const onPop = () =>
      setLocation((prev) => ({
        path: normalizePath(window.location.pathname),
        hash: window.location.hash.replace(/^#/, ''),
        key: prev.key + 1,
        samePage: prev.path === normalizePath(window.location.pathname),
      }));
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  // Scroll handling after each navigation
  useEffect(() => {
    const behavior: ScrollBehavior = location.samePage ? 'smooth' : 'auto';
    if (location.hash) {
      // Wait one frame so the new page is in the DOM
      requestAnimationFrame(() => {
        document.getElementById(location.hash)?.scrollIntoView({ behavior, block: 'start' });
      });
    } else if (location.key > 0) {
      window.scrollTo({ top: 0, behavior });
    }
  }, [location]);

  return <RouterContext.Provider value={{ location, navigate }}>{children}</RouterContext.Provider>;
}

export function useRouter(): RouterValue {
  const ctx = useContext(RouterContext);
  if (!ctx) throw new Error('useRouter must be used inside <RouterProvider>');
  return ctx;
}

type LinkProps = AnchorHTMLAttributes<HTMLAnchorElement> & { to: string };

/** A real <a href> that navigates without a page reload. Ctrl/Cmd-click still opens a new tab. */
export function Link({ to, onClick, children, ...rest }: LinkProps) {
  const { navigate } = useRouter();
  const handleClick = (e: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(e);
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    navigate(to);
  };
  return (
    <a href={to} onClick={handleClick} {...rest}>
      {children}
    </a>
  );
}
