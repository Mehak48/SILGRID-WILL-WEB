/**
 * API CLIENT — the only place the website sends data anywhere.
 * ─────────────────────────────────────────────────────────────
 * Current setup: NETLIFY FORMS.
 *   • The form definition lives in public/__forms.html (Netlify reads it
 *     at deploy time; field names there must match the fields below).
 *   • Netlify stores each enquiry (Netlify → Forms) and emails a
 *     notification to the address set in Netlify → Forms → Notifications.
 *   • No passwords or API keys are needed.
 *
 * Success is shown ONLY when Netlify accepts the submission (HTTP 2xx).
 * If form detection is off, Netlify rejects the POST and the visitor sees
 * an error with the fallback email address — never a fake success.
 *
 * (The optional PHP backend in /backend is kept for a future move to PHP
 *  hosting; set VITE_CONTACT_ENDPOINT=/api/contact.php to use it again.)
 */
import { site } from '../config/site';
import type { ContactFormValues, FieldErrors } from './validation';

export interface ContactPayload extends ContactFormValues {
  /** Honeypot field — always empty for humans; bots tend to fill it. */
  website: string;
  sourcePage: string;
}

export type SubmitResult =
  | { ok: true }
  | {
      ok: false;
      kind: 'validation' | 'rate_limited' | 'not_configured' | 'server' | 'network';
      message: string;
      fieldErrors?: FieldErrors;
    };

/** Must match the `name` attribute of the form in public/__forms.html */
const NETLIFY_FORM_NAME = 'contact';
const TIMEOUT_MS = 20000;

export async function submitContact(payload: ContactPayload): Promise<SubmitResult> {
  const usePhpBackend = site.contactEndpoint.endsWith('.php');
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), TIMEOUT_MS);

  let res: Response;
  try {
    res = usePhpBackend
      ? await fetch(site.contactEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
          body: JSON.stringify(payload),
          signal: controller.signal,
        })
      : await fetch(site.contactEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ 'form-name': NETLIFY_FORM_NAME, ...payload }).toString(),
          signal: controller.signal,
        });
  } catch {
    return {
      ok: false,
      kind: 'network',
      message: 'We could not reach the server. Please check your connection and try again.',
    };
  } finally {
    window.clearTimeout(timer);
  }

  // ── Netlify Forms ──
  if (!usePhpBackend) {
    if (res.ok) return { ok: true };
    return {
      ok: false,
      kind: res.status === 429 ? 'rate_limited' : 'server',
      message:
        res.status === 429
          ? 'Too many requests. Please try again later.'
          : 'Your message could not be sent right now. Please try again shortly.',
    };
  }

  // ── Optional PHP backend (JSON API) ──
  let data: Record<string, unknown> | null = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }
  if (res.ok && data && data.ok === true) return { ok: true };

  const serverMessage = typeof data?.message === 'string' ? data.message : '';
  switch (res.status) {
    case 422:
      return {
        ok: false,
        kind: 'validation',
        message: serverMessage || 'Please check the highlighted fields.',
        fieldErrors: (data?.errors as FieldErrors) ?? {},
      };
    case 429:
      return { ok: false, kind: 'rate_limited', message: serverMessage || 'Too many requests. Please try again later.' };
    case 503:
      return { ok: false, kind: 'not_configured', message: serverMessage || 'The contact service is not available yet.' };
    default:
      return {
        ok: false,
        kind: 'server',
        message: serverMessage || 'The contact service is not available right now.',
      };
  }
}
