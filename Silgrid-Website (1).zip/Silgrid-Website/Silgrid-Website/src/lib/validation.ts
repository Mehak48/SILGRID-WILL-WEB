/**
 * Client-side validation for the contact form.
 * These rules MIRROR the server-side rules in backend/app/src/ContactValidator.php.
 * The server always re-validates — never trust the browser alone.
 */
export interface ContactFormValues {
  name: string;
  email: string;
  company: string;
  phone: string;
  service: string;
  message: string;
}

export type FieldErrors = Partial<Record<keyof ContactFormValues, string>>;

export const LIMITS = {
  nameMin: 2,
  nameMax: 100,
  emailMax: 254,
  companyMax: 150,
  phoneMax: 40,
  messageMin: 10,
  messageMax: 5000,
} as const;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_RE = /^[+()\-.\s0-9]{6,40}$/;

export function validateContact(v: ContactFormValues, allowedServices: string[]): FieldErrors {
  const e: FieldErrors = {};
  const name = v.name.trim();
  const email = v.email.trim();
  const message = v.message.trim();

  if (!name) e.name = 'Please enter your name.';
  else if (name.length < LIMITS.nameMin) e.name = 'Name is too short.';
  else if (name.length > LIMITS.nameMax) e.name = `Name must be under ${LIMITS.nameMax} characters.`;

  if (!email) e.email = 'Please enter your email address.';
  else if (email.length > LIMITS.emailMax || !EMAIL_RE.test(email)) e.email = 'Please enter a valid email address.';

  if (v.company.trim().length > LIMITS.companyMax) e.company = `Company must be under ${LIMITS.companyMax} characters.`;

  const phone = v.phone.trim();
  if (phone && !PHONE_RE.test(phone)) e.phone = 'Please enter a valid phone number.';

  if (!v.service) e.service = 'Please choose a service.';
  else if (!allowedServices.includes(v.service)) e.service = 'Please choose a service from the list.';

  if (!message) e.message = 'Please tell us about your requirements.';
  else if (message.length < LIMITS.messageMin) e.message = `Please write at least ${LIMITS.messageMin} characters.`;
  else if (message.length > LIMITS.messageMax) e.message = `Message must be under ${LIMITS.messageMax} characters.`;

  return e;
}
