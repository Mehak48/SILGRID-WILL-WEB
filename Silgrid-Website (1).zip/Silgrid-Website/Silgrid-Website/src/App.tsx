import { useEffect } from 'react';
import { RouterProvider, useRouter, type RoutePath } from './lib/router';
import { ContactProvider } from './components/contact/ContactProvider';
import { Nav } from './components/layout/Nav';
import { Footer } from './components/layout/Footer';
import { HomePage } from './pages/HomePage';
import { ServicesPage } from './pages/ServicesPage';
import { NotFoundPage } from './pages/NotFoundPage';

/** Official domain — used for the canonical link (SEO). */
const SITE_URL = 'https://www.silgrid.net';

const TITLES: Record<RoutePath, string> = {
  '/': 'SILGRID — Industrial & IT Solutions Provider',
  '/services': 'Our Services — SILGRID',
  '404': 'Page not found — SILGRID',
};

function CurrentPage() {
  const { location } = useRouter();

  useEffect(() => {
    document.title = TITLES[location.path];
    const canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (canonical) canonical.href = SITE_URL + (location.path === '404' ? '/' : location.path);
  }, [location.path]);

  switch (location.path) {
    case '/':
      return <HomePage />;
    case '/services':
      return <ServicesPage />;
    default:
      return <NotFoundPage />;
  }
}

export default function App() {
  return (
    <RouterProvider>
      <ContactProvider>
        <Nav />
        <main style={{ paddingTop: 'var(--nav-height)' }}>
          <CurrentPage />
        </main>
        <Footer />
      </ContactProvider>
    </RouterProvider>
  );
}
