import { images } from '../config/assets';
import { services } from '../data/content';
import { Button } from '../components/ui/Button';
import { Eyebrow } from '../components/ui/SectionHeading';
import { useContact } from '../components/contact/ContactProvider';
import './ServicesPage.css';

export function ServicesPage() {
  const { openContact } = useContact();

  return (
    <>
      {/* ── Page hero ────────────────────────────────────── */}
      <section className="services-hero" aria-labelledby="services-page-title">
        <div className="services-hero__bg" style={{ backgroundImage: `url(${images.servicesHero})` }} aria-hidden="true" />
        <div className="services-hero__content container">
          <Eyebrow label="What We Offer" />
          <h1 id="services-page-title" className="services-hero__title">
            Our Services
          </h1>
          <p className="services-hero__text">
            Six integrated service areas covering industrial supply, technology procurement, and professional support
            for technically demanding organisations.
          </p>
        </div>
      </section>

      {/* ── Service detail sections (alternating layout) ─── */}
      {services.map((svc, i) => {
        const reversed = i % 2 === 1;
        return (
          <section
            key={svc.id}
            id={svc.id}
            className={`service-detail ${reversed ? 'service-detail--reversed' : ''}`}
            aria-labelledby={`${svc.id}-title`}
          >
            <div className="service-detail__grid container">
              <div className="service-detail__media">
                <div className="service-detail__frame" aria-hidden="true" />
                <img
                  src={svc.image}
                  alt={svc.imageAlt}
                  className="service-detail__img"
                  loading={i === 0 ? 'eager' : 'lazy'}
                  width={700}
                  height={600}
                />
              </div>
              <div className="service-detail__text">
                <Eyebrow label={`Service ${String(i + 1).padStart(2, '0')}`} lineWidth={28} small />
                <h2 id={`${svc.id}-title`} className="service-detail__title">
                  {svc.pageTitle}
                </h2>
                <p className="service-detail__body">{svc.pageBody}</p>
                <ul className="service-detail__bullets">
                  {svc.bullets.map((b) => (
                    <li key={b}>{b}</li>
                  ))}
                </ul>
                <Button variant="solid" onClick={() => openContact(svc.pageTitle)}>
                  REQUEST CONSULTATION
                </Button>
              </div>
            </div>
          </section>
        );
      })}

      {/* ── Closing call to action ───────────────────────── */}
      <section id="services-footer" className="services-cta" aria-labelledby="services-cta-title">
        <div className="services-cta__inner">
          <div className="services-cta__line" aria-hidden="true" />
          <h2 id="services-cta-title" className="services-cta__title">
            Partner With SILGRID
          </h2>
          <p className="services-cta__text">
            Whether you require a single-source supply agreement, specialist procurement support, or an integrated
            technology and materials solution, our team is ready to engage. We work across sectors and geographies to
            deliver outcomes that keep your operations running.
          </p>
          <div className="services-cta__actions">
            <Button variant="solid-plain" size="xl" onClick={() => openContact()}>
              REQUEST A CONSULTATION
            </Button>
            <Button variant="outline" size="xl" to="/">
              BACK TO HOME
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
