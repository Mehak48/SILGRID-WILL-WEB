import { images } from '../config/assets';
import { industries, services, stats, whyUs } from '../data/content';
import { Button } from '../components/ui/Button';
import { Eyebrow, SectionHeading } from '../components/ui/SectionHeading';
import { ServiceCard } from '../components/cards/ServiceCard';
import { IndustryTag } from '../components/cards/IndustryTag';
import { useContact } from '../components/contact/ContactProvider';
import './HomePage.css';

export function HomePage() {
  const { openContact } = useContact();

  return (
    <>
      {/* ── Hero ─────────────────────────────────────────── */}
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero__bg" style={{ backgroundImage: `url(${images.hero})` }} aria-hidden="true" />
        <div className="hero__overlay" aria-hidden="true" />
        <div className="hero__content">
          <Eyebrow label="International Procurement & Technology" lineWidth={40} className="hero__eyebrow" />
          <h1 id="hero-title" className="hero__title">
            One Reliable Source
            <br /> for Industrial &amp;
            <br /> IT Solutions
          </h1>
          <p className="hero__text">
            Industrial materials, technical supplies, IT solutions, procurement, and professional support for
            organizations across technical sectors.
          </p>
          <div className="hero__actions">
            <Button variant="hero-primary" size="lg" to="/services">
              EXPLORE OUR SERVICES
            </Button>
            <Button variant="hero-ghost" size="lg" to="/#contact">
              CONTACT US
            </Button>
          </div>
        </div>
      </section>

      {/* ── Stats bar ────────────────────────────────────── */}
      <div className="stats">
        <dl className="stats__grid">
          {stats.map((s) => (
            <div key={s.label} className="stats__item">
              <dt className="stats__label">{s.label}</dt>
              <dd className="stats__value">{s.value}</dd>
            </div>
          ))}
        </dl>
      </div>

      {/* ── About ────────────────────────────────────────── */}
      <section id="about" className="about" aria-labelledby="about-title">
        <div className="about__grid container">
          <div>
            <Eyebrow label="About SILGRID" className="about__eyebrow" />
            <h2 id="about-title" className="about__title">
              Supporting Industry Through Reliable Supply &amp; Technology
            </h2>
            <p className="about__text">
              SILGRID is an international procurement and technology solutions company, founded to bridge the gap
              between industrial supply and modern IT infrastructure. We serve organizations that demand precision,
              reliability, and scale.
            </p>
            <p className="about__text about__text--last">
              From sourcing specialist materials for critical infrastructure projects to deploying enterprise
              technology systems across multiple geographies, our team delivers integrated solutions that keep
              technical operations moving forward.
            </p>
            <Button variant="outline" to="/services">
              OUR SERVICES
            </Button>
          </div>
          <div className="about__media">
            <div className="about__frame" aria-hidden="true" />
            <img
              src={images.about}
              alt="Industrial factory floor with heavy equipment and steel structures"
              className="about__img"
              loading="lazy"
              width={600}
              height={450}
            />
          </div>
        </div>
      </section>

      {/* ── Services ─────────────────────────────────────── */}
      <section id="services-overview" className="home-section home-section--grey" aria-labelledby="services-title">
        <div className="container">
          <SectionHeading eyebrow="What We Do" title="Our Services" id="services-title" />
          <div className="services-grid">
            {services.map((svc) => (
              <ServiceCard key={svc.id} service={svc} />
            ))}
          </div>
        </div>
      </section>

      {/* ── Industries ───────────────────────────────────── */}
      <section id="industries" className="home-section" aria-labelledby="industries-title">
        <div className="container">
          <SectionHeading eyebrow="Sectors" title="Industries We Serve" id="industries-title" />
          <ul className="industries-grid">
            {industries.map((ind) => (
              <IndustryTag key={ind.label} {...ind} />
            ))}
          </ul>
        </div>
      </section>

      {/* ── Why SILGRID ──────────────────────────────────── */}
      <section id="why-silgrid" className="home-section home-section--grey" aria-labelledby="why-title">
        <div className="container">
          <SectionHeading eyebrow="Our Advantage" title="Why Choose SILGRID" id="why-title" />
          <div className="why-grid">
            {whyUs.map((item) => (
              <div key={item.title} className="why-item">
                <img src={item.icon} alt="" width={50} height={50} className="why-item__icon" loading="lazy" />
                <h3 className="why-item__title">{item.title}</h3>
                <p className="why-item__desc">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Call to action ───────────────────────────────── */}
      <section id="contact" className="cta" aria-labelledby="cta-title">
        <div className="cta__inner">
          <div className="cta__line" aria-hidden="true" />
          <h2 id="cta-title" className="cta__title">
            Looking for a Reliable Supply &amp; Technology Partner?
          </h2>
          <p className="cta__text">
            Speak with our team about your industrial materials, IT, or procurement requirements. We respond within
            one business day.
          </p>
          <Button variant="gold" size="cta" onClick={() => openContact()}>
            CONTACT SILGRID
          </Button>
        </div>
      </section>
    </>
  );
}
