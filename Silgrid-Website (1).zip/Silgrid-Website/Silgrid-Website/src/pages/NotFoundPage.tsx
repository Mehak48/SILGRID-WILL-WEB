import { Button } from '../components/ui/Button';
import './NotFoundPage.css';

export function NotFoundPage() {
  return (
    <section className="not-found" aria-labelledby="not-found-title">
      <p className="not-found__code">404</p>
      <h1 id="not-found-title" className="not-found__title">
        Page not found
      </h1>
      <p className="not-found__text">The page you are looking for does not exist or has been moved.</p>
      <Button variant="solid" to="/">
        BACK TO HOME
      </Button>
    </section>
  );
}
