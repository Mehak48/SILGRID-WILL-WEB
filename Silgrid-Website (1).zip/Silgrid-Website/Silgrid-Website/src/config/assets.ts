/**
 * CENTRAL ASSET REGISTRY
 * ─────────────────────────────────────────────────────────────
 * Every image, icon and logo on the website is referenced from here.
 * All files live in /public/assets/ and are served at /assets/...
 *
 * To change an image: overwrite the file in public/assets/images/
 * with a new one using the SAME filename. No code changes needed —
 * this also works on the live server (just re-upload the file).
 *
 * Only edit this file if you want to use a DIFFERENT filename.
 */

const img = (file: string) => `/assets/images/${file}`;
const icon = (file: string) => `/assets/icons/${file}`;

export const images = {
  logo: img('logo.png'),
  hero: img('hero.jpg'),
  about: img('about.jpg'),
  servicesHero: img('services-hero.jpg'),
  serviceIndustrial: img('service-industrial.jpg'),
  serviceItHardware: img('service-it-hardware.jpg'),
  serviceSoftware: img('service-software.jpg'),
  serviceItSupport: img('service-it-support.jpg'),
  serviceProcurement: img('service-procurement.jpg'),
  serviceManagement: img('service-management.jpg'),
} as const;

export const icons = {
  // Service icons (navy, 40×40)
  industrial: icon('industrial.svg'),
  itHardware: icon('it-hardware.svg'),
  software: icon('software.svg'),
  itSupport: icon('it-support.svg'),
  procurement: icon('procurement.svg'),
  management: icon('management.svg'),
  // Industry icons (navy, 40×40)
  manufacturing: icon('industry-manufacturing.svg'),
  oilGas: icon('industry-oil-gas.svg'),
  energy: icon('industry-energy.svg'),
  engineering: icon('industry-engineering.svg'),
  construction: icon('industry-construction.svg'),
  aviation: icon('industry-aviation.svg'),
  technology: icon('industry-technology.svg'),
  // "Why choose us" icons (gold, 50×50)
  reliableSourcing: icon('why-reliable-sourcing.svg'),
  technicalExpertise: icon('why-technical-expertise.svg'),
  integratedSolutions: icon('why-integrated-solutions.svg'),
  professionalSupport: icon('why-professional-support.svg'),
} as const;
