/**
 * SITE-WIDE SETTINGS
 * ─────────────────────────────────────────────────────────────
 * Company details shown in the footer and elsewhere.
 * Confirmed by the client. Add the full street address to `location`
 * when it becomes available.
 */
export const site = {
  name: 'SILGRID',
  legalName: 'SILGRID WLL',
  /** Full meaning of the SILGRID acronym (shown under the name in the navbar). */
  fullName: 'Strategic Industrial Logistics, Global Resources & Integrated Distribution',
  tagline: 'Industrial & IT Solutions Provider',
  footerDescription:
    'International industrial materials, IT solutions, and technology procurement company.',
  contact: {
    /** Support email (also used as the fallback on the contact form). */
    email: 'info@silgrid.net',
    salesEmail: 'sales@silgrid.net',
    phone: '+973-366737565',
    /** Head office address — one line per entry. */
    address: [
      'Office: 445, Building No.: 318, Road No.: 328,',
      'Block No.: 357, Town: Al Burhama,',
      'Manama Municipality, the Kingdom of Bahrain',
    ],
  },
  brand: {
    /** Also show the "SILGRID" text next to the logo image in the header. */
    showWordmarkNextToLogo: true,
  },
  /**
   * How the contact form sends enquiries.
   * Default 'mailto' (Cloudflare Pages, no form service): the form opens the
   * visitor's email app with the enquiry pre-filled, addressed to salesEmail.
   * Other values: '/api/contact.php' (PHP hosting) or '/__forms.html' (Netlify).
   */
  contactEndpoint: import.meta.env.VITE_CONTACT_ENDPOINT || 'mailto',
} as const;
